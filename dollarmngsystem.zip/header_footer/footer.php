<div class="container-fluid bg-primary h-25 p-3 ">
    <div class="container text-center ">
    <p class="text-white fw-semibold mb-0">&copy; 2024 jss dollar tracking system. All rights reserved.</p>
    </div>
</div>